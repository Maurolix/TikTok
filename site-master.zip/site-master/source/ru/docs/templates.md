---
title: Шаблоны
---
Шаблон определяет, как страница определённого вида будет выглядеть на вашем сайте. В таблице ниже приведены соответствующие шаблоны для любой страницы. Как минимум, тема должна содержать шаблон `index`.

Шаблон | Страница | Резерв
--- | --- | ---
`index` | Домашняя страница |
`post` | Посты | `index`
`page` | Страницы | `index`
`archive` | Архив | `index`
`category` | Категории архивов | `archive`
`tag` | Архив тегов | `archive`

## Макеты

Если страницы имеют схожую структуру, например, когда два шаблона имеют как верхний, так и нижний колонтитулы, тогда можно рассмотреть возможность использования макета `layout` для вынесения этих структурных сходств. Каждый файл разметки должен содержать переменную `body`, для отображения содержимого шаблона. Например:

``` html index.ejs
index
```

``` html layout.ejs
<!DOCTYPE html>
<html>
  <body><%- body %></body>
</html>
```

сформируется в:

``` html
<!DOCTYPE html>
<html>
  <body>index</body>
</html>
```

По умолчанию макет `layout` используется всеми другими шаблонами. Вы можете указать дополнительные макеты в шапке файла или установить его значение в `false`, чтобы отключить. Также можно построить сложную вложенную структуру включив в верхней части макета другие макеты.
<!-- TODO: Добавить примеры использования -->

## Части

Разбивка на части полезна для обмена компонентами между шаблонами. Типичные примеры включают в себя заголовки, нижние колонтитулы, боковые панели. Можно подставить ваш фрагмент в отдельные файлы, чтобы сделать поддержку сайта намного удобнее. Например:

``` html partial/header.ejs
<h1 id="logo"><%= config.title %></h1>
```

``` html index.ejs
<%- partial('partial/header') %>
<div id="content">Home page</div>
```

сформируется в:

``` html
<h1 id="logo">My Site</h1>
<div id="content">Home page</div>
```

## Локальные переменные

Вы можете назначать локальные переменные в шаблонах и после использовать в других шаблонах.

``` html partial/header.ejs
<h1 id="logo"><%= title></h1>
```

``` html index.ejs
<%- partial('partial/header', {title: 'Hello World'}) %>
<div id="content">Home page</div>
```

сформируется в:

``` html
<h1 id="logo">Hello World</h1>
<div id="content">Home page</div>
```

## Оптимизация

Если созданная тема является чрезвычайно сложной или в ней количество файлов для создания становится слишком большим, производительность генерация файлов Hexo может начать значительно уменьшаться. Помимо упрощения вашей темы, можно попробовать кэширование фрагментов, оно было введено в Hexo 2.7.

Эта было позаимствовано из [Ruby on Rails](http://guides.rubyonrails.org/caching_with_rails.html#fragment-caching). Он вызывает содержимое для сохранения в виде фрагментов и кэширует его, когда дополнительные запросы выполнены. Это может уменьшить количество запросов к базе данных, а также может ускорить создание файлов.

Кэширование фрагментов лучше всего использовать для заголовков, колонтитулов, боковых панелей или другого статического контента, который вряд ли будет менятся от шаблона к шаблону. Например:

``` js
<%- fragment_cache('header', function(){
  return '<header></header>';
});
```

Хотя это можно сделать проще, используя части:

``` js
<%- partial('header', {}, {cache: true});
```

{% note warn %}
`fragment_cache()` will cache the rendered result and output the cached result to other pages. This should only be used on partials that are expected **not** to change across different pages. Otherwise, it should **not** be enabled.
For example, it should be disabled when `relative_link` is enabled in the config. This is because relative links may appear differently across pages.
{% endnote %}
