---
title: Команды
---

## init

``` bash
$ hexo init [folder]
```

Инициализирует сайт. Если переменная `folder` не указана, Hexo создаёт сайт в текущей папке.

This command is a shortcut that runs the following steps:

1. Git clone [hexo-starter](https://github.com/hexojs/hexo-starter) including [hexo-theme-landscape](https://github.com/hexojs/hexo-theme-landscape) into the current directory or a target folder if specified.
2. Install dependencies using a package manager: [Yarn 1](https://classic.yarnpkg.com/lang/en/), [pnpm](https://pnpm.js.org) or [npm](https://docs.npmjs.com/cli/install), whichever is installed; if there are more than one installed, the priority is as listed. npm is bundled with [Node.js](/docs/#Install-Node-js) by default.

## new

``` bash
$ hexo new [layout] <title>
```

Будет создана новая статья. Если макет не был указан, Hexo будет использовать значение `default_layout`, указанное в  [_config.yml](configuration.html). Если название содержит пробелы, заключите его в кавычки.

## generate

``` bash
$ hexo generate
```

Генерирует статичные файлы.

Параметр | Описание
--- | ---
`-d`, `--deploy` | Опубликовать после генерации
`-w`, `--watch` | Отслеживать изменения файлов

## publish

``` bash
$ hexo publish [layout] <filename>
```

Переносит черновик в публикуемую папку.

## server

``` bash
$ hexo server
```

Запускает локальный сервер. По умолчанию адрес: `http://localhost:4000/`.

Параметр | Описание
--- | ---
`-p`, `--port` | Переназначает стандартный порт
`-s`, `--static` | Обрабатывать только статичные файлы
`-l`, `--log` | Включить журналирование. Переопределяет формат журнала.

## deploy

``` bash
$ hexo deploy
```

Публикует сайт.

Параметр | Описание
--- | ---
`-g`, `--generate` | Генерировать перед публикацией

## render

``` bash
$ hexo render <file1> [file2] ...
```

Генерирует файлы.

Параметр | Описание
--- | ---
`-o`, `--output` | Путь вывода

## migrate

``` bash
$ hexo migrate <type>
```

[Миграция](migration.html) контента из других систем.

## clean

``` bash
$ hexo clean
```

Очищает кэш (`db.json`) и генерирует файлы для опубликования (`public`).

## list

``` bash
$ hexo list <type>
```

Список всех путей.

## version

``` bash
$ hexo version
```

Отображает информацию о версии Hexo.

## Опции

### Безопасный режим

``` bash
$ hexo --safe
```

Отключает загрузку плагинов и скриптов. Применяется при возникновении проблем после установки нового плагина.

### Режим отладки

``` bash
$ hexo --debug
```

Журнал подробных сообщений в терминале и `debug.log`. Применяется при возникновении проблем с Hexo. Если выдаются ошибки, пожалуйста, задайте вопрос на [GitHub](https://github.com/hexojs/hexo/issues/new).

### Тихий режим

``` bash
$ hexo --silent
```

Отключает показ сообщений в консоли.

### Альтернативная конфигурация

``` bash
$ hexo --config custom.yml
```

Использует другой конфигурационный файл (вместо `_config.yml`).

### Показать черновики

``` bash
$ hexo --draft
```

Отображает черновики (хранящиеся в папке `source/_drafts`).

### Изменить рабочую папку

``` bash
$ hexo --cwd /path/to/cwd
```

Изменяет путь к текущей рабочей папке.
