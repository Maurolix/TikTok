---
title: Scaffolds
---
## Получить Scaffold

``` js
hexo.scaffold.get(name);
```

## Установить Scaffold

``` js
hexo.scaffold.set(name, content);
```

## Удалить Scaffold

``` js
hexo.scaffold.remove(name);
```