---
title: 脚手架（Scaffold）
---
## 获得脚手架

``` js
hexo.scaffold.get(name);
```

## 设置脚手架

``` js
hexo.scaffold.set(name, content);
```

## 移除脚手架

``` js
hexo.scaffold.remove(name);
```
