---
title: 处理器（Processor）
---
处理器用于处理 `source` 文件夹内的原始文件。

## 概要

``` js
hexo.extend.processor.register(rule, function(file){
});
```

完整说明请参考 [Box](box.html)。
