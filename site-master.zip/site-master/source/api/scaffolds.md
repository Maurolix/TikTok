---
title: Scaffolds
---
## Get a Scaffold

``` js
hexo.scaffold.get(name);
```

## Set a Scaffold

``` js
hexo.scaffold.set(name, content);
```

## Remove a Scaffold

``` js
hexo.scaffold.remove(name);
```
