---
title: Processor
---
A processor is used to process source files in the `source` folder.

## Synopsis

``` js
hexo.extend.processor.register(rule, function(file){
 // ...
});
```

For more info, see [box](box.html).
