---
title: Processor
---
`source` 폴더 내의 소스 파일들을 처리할 때 프로세서를 사용합니다.

## 개요

``` js
hexo.extend.processor.register(rule, function(file){
 // ...
});
```

더 많은 정보를 원하신다면 [box](box.html)를 확인하세요.
