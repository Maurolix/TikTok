---
title: Scaffolds
---
## Scaffold 얻어오기

``` js
hexo.scaffold.get(name);
```

## Scaffold 설정하기

``` js
hexo.scaffold.set(name, content);
```

## Scaffold의 제거

``` js
hexo.scaffold.remove(name);
```
