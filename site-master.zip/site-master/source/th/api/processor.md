---
title: Processor
---
processor ใช้มาจัดการไฟล์ source ท่ีอยู่ใน folder `source`

## Synopsis

``` js
hexo.extend.processor.register(rule, function(file){
 // ...
});
```

สำหรับข้อมูลเพิ่มเติม ไปดูได้ที่ [box](box.html).
