---
title: Scaffolds
---
## Obter um Scaffold

``` js
hexo.scaffold.get(name);
```

## Definir um Scaffold

``` js
hexo.scaffold.set(name, content);
```

## Remover um Scaffold

``` js
hexo.scaffold.remove(name);
```
