---
title: Processor
---

Um `processor` é utilizado para processar os arquivos fontes contidos no diretório `source`.

## Resumo

``` js
hexo.extend.processor.register(rule, function(file){
 // ...
});
```

Mais informações podem ser encontradas em [box](box.html).
