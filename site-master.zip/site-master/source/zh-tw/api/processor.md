---
title: 處理器（Processor）
---
處理器用於處理 `source` 資料夾內的原始檔案。

## 概要

``` js
hexo.extend.processor.register(rule, function(file){
  // ...
});
```

完整說明請參照 [箱子](box.html)。
