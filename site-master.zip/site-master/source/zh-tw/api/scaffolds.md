---
title: 鷹架（Scaffold）
---
## 取得鷹架

``` js
hexo.scaffold.get(name);
```

## 設定鷹架

``` js
hexo.scaffold.set(name, content);
```

## 移除鷹架

``` js
hexo.scaffold.remove(name);
```
